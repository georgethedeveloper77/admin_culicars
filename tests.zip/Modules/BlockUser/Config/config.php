<?php

return [
    'name' => 'BlockUser'
];
