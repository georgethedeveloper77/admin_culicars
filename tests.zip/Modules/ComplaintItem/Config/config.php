<?php

return [
    'name' => 'ComplaintItem'
];
