<?php

return [
    'name' => 'Chat'
];
